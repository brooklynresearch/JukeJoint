extern const unsigned int guitar_b3_note[52184];
